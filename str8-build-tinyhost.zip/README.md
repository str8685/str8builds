# STR8 Build - Tinyhost Deployment

## After Uploading
1. Set these environment variables in Tinyhost dashboard:
   - DATABASE_URL: Your database connection string
   - SMTP_PASSWORD: Email service password (if used)
   - Any API keys needed by your application

2. Make sure to select Node.js as the runtime environment

3. Set the start command to: `node server.js`

## Note
All files should already be properly configured for Tinyhost deployment.
